default[:images] = {
  :names => [
    'lobo1111/flexget',
    'lobo1111/series_filter',
    'lobo1111/transmission',
    'lobo1111/emby',
    'stevepacker/samba-alpine'		
  ]
}
