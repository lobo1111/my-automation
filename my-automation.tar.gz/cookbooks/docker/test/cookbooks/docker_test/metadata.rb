name 'docker_test'
maintainer 'Sean OMeara'
maintainer_email 'sean@sean.io'
license 'Apache-2.0'
description 'installs a buncha junk'
version '0.6.0'

depends 'docker'
depends 'etcd'
