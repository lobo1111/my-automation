default[:repos] = {
  :names => [
    'flexget',
    'transmission',
    'series_filter'		
  ]
}
