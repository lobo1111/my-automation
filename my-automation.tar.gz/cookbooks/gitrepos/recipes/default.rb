#
# Cookbook Name:: gitrepos
# Recipe:: default
#
# Copyright (c) 2017 The Authors, All Rights Reserved.

package 'git'

node[:repos][:names].each do |repo|
  git repo do
    repository 'https://github.com/lobo1111/' + repo + '.git'
    destination '/opt/my-automation/repos/' + repo + '/'
    revision 'master'
    action :checkout
  end
end
